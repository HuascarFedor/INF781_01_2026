# INF781 — Examen Parcial Práctico

## Insecure Notes: Aplicación PHP pura intencionalmente vulnerable

> ⚠️ **ADVERTENCIA:** Esta aplicación contiene vulnerabilidades de seguridad introducidas de forma deliberada con fines educativos. **NUNCA** debe desplegarse en un servidor público ni usarse fuera del entorno de laboratorio.

---

## Requisitos

- PHP 8.3+ con extensión `pgsql` habilitada
- PostgreSQL 14+
- Navegador web (Chrome, Firefox o similar)
- Editor de código (VS Code, Sublime, etc.)

Verificar versiones:

```bash
php -v
php -m | grep pgsql
psql --version
```

---

## Setup del entorno (10 minutos)

### 1. Clonar / descomprimir el proyecto

```bash
cd ~/examen-inf781
# el docente entregará el ZIP o el enlace al repositorio
```

### 2. Crear la base de datos

```bash
# Conectarse a PostgreSQL como superusuario
psql -U postgres

# Dentro de psql:
CREATE DATABASE examen_insecure_notes;
\q
```

### 3. Cargar el esquema y los datos de prueba

```bash
psql -U postgres -d examen_insecure_notes -f sql/schema.sql
psql -U postgres -d examen_insecure_notes -f sql/seed.sql
```

### 4. Ajustar credenciales (si es necesario)

Abrir `config.php` y verificar las variables `$db_user` y `$db_pass` coincidan con tu instalación local de PostgreSQL.

### 5. Iniciar el servidor

```bash
php -S localhost:8000
```

### 6. Acceder desde el navegador

Abrir `http://localhost:8000`

**Usuarios de prueba:**

| Email | Contraseña | Rol |
|---|---|---|
| `admin@uatf.edu` | `admin123` | Administrador |
| `estudiante@uatf.edu` | `123456` | Estudiante |
| `docente@uatf.edu` | `password` | Docente |

---

## Estructura del proyecto

```
examen-insecure-notes/
├── config.php              # Conexión BD + configuración de sesiones
├── index.php               # Redirección inicial
├── login.php               # Formulario + lógica de login
├── logout.php              # Destruir sesión
├── notes/
│   ├── index.php           # Listar notas del usuario
│   ├── create.php          # Formulario de creación
│   ├── store.php           # Procesar INSERT
│   ├── edit.php            # Formulario de edición
│   ├── update.php          # Procesar UPDATE
│   └── delete.php          # Procesar DELETE
├── attacks/
│   └── csrf-attack.html    # Página para demostrar CSRF
├── sql/
│   ├── schema.sql          # Tablas users y notes
│   └── seed.sql            # Datos de prueba
└── README.md
```

---

## Funcionalidades verificables antes del examen

Antes de comenzar el examen, confirma que:

- [ ] Puedes iniciar sesión con `admin@uatf.edu` / `admin123`
- [ ] Ves 3 notas listadas en la vista principal
- [ ] Puedes crear una nueva nota
- [ ] Puedes editar una nota existente
- [ ] Puedes eliminar una nota (con confirmación)
- [ ] Puedes cerrar sesión y volver al login

Si algo falla, avisa al docente **antes** de iniciar el tiempo del examen.

---

## Consignas del examen

Consulta el documento **"Enunciado del Examen Parcial — INF781"** entregado aparte. El enunciado detalla las 3 secciones a resolver, las capturas de pantalla requeridas, la rúbrica y el formato de entrega.

---

## Entregables

1. **Código fuente corregido** (ZIP o repositorio GitHub privado con el docente como colaborador).
2. **Informe del examen** (PDF) con las capturas de pantalla requeridas por cada sección.

---

UATF — Facultad de Ciencias Puras — Ingeniería Informática
Gestión 2026 — Potosí, Bolivia
