<?php
// =============================================================
// login.php - Autenticación de usuarios
// Vulnerabilidades intencionales: SQL Injection, hashing MD5
// =============================================================
require_once __DIR__ . '/config.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = $_POST['email']    ?? '';
    $password = $_POST['password'] ?? '';

    // VULNERABLE: concatenación directa + MD5 inseguro
    $query = "SELECT id, name, email FROM users WHERE email = '$email' AND password = '" . md5($password) . "'";
    echo $query;
    $result = pg_query($conn, $query);

    if ($result && pg_num_rows($result) > 0) {
        $user = pg_fetch_assoc($result);

        // NO se regenera el session ID después del login (permite fijación)
        $_SESSION['user_id']   = $user['id'];
        $_SESSION['user_name'] = $user['name'];

        redirect('/notes/index.php');
    } else {
        $error = 'Credenciales inválidas.';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login - Insecure Notes</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 400px; margin: 60px auto; padding: 20px; }
        h1 { color: #334155; }
        label { display: block; margin-top: 12px; font-weight: bold; }
        input { width: 100%; padding: 8px; margin-top: 4px; box-sizing: border-box; }
        button { margin-top: 16px; padding: 10px 20px; background: #E0234E; color: white; border: none; cursor: pointer; }
        .error { color: #E0234E; margin-top: 10px; }
        .hint { background: #F1F5F9; padding: 12px; margin-top: 20px; font-size: 13px; }
    </style>
</head>
<body>
    <h1>Insecure Notes — Login</h1>

    <?php if ($error): ?>
        <p class="error"><?php echo $error; ?></p>
    <?php endif; ?>

    <form method="POST" action="login.php">
        <label>Email:</label>
        <input type="text" name="email" required>

        <label>Contraseña:</label>
        <input type="password" name="password" required>

        <button type="submit">Iniciar Sesión</button>
    </form>

    <div class="hint">
        <strong>Usuarios de prueba:</strong><br>
        admin@uatf.edu / admin123<br>
        estudiante@uatf.edu / 123456
    </div>
</body>
</html>
