<?php
require_once __DIR__ . '/../config.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/notes/index.php');
}

$id      = $_POST['id']      ?? 0;
$title   = $_POST['title']   ?? '';
$content = $_POST['content'] ?? '';
$user_id = $_SESSION['user_id'];

// VULNERABLE: concatenación directa, sin token CSRF
$query = "UPDATE notes
          SET title = '$title', content = '$content'
          WHERE id = $id AND user_id = $user_id";

pg_query($conn, $query);
redirect('/notes/index.php');
