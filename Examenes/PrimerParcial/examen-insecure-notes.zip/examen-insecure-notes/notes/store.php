<?php
// =============================================================
// notes/store.php - Procesar creación de nota
// Vulnerabilidades intencionales: SQL Injection, sin token CSRF
// =============================================================
require_once __DIR__ . '/../config.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/notes/create.php');
}

$title   = $_POST['title']   ?? '';
$content = $_POST['content'] ?? '';
$user_id = $_SESSION['user_id'];

// VULNERABLE: concatenación directa (permite SQLi) y sin validación
$query = "INSERT INTO notes (title, content, user_id)
          VALUES ('$title', '$content', $user_id)";

$result = pg_query($conn, $query);

if ($result) {
    redirect('/notes/index.php');
} else {
    echo "Error al guardar la nota: " . pg_last_error($conn);
}
