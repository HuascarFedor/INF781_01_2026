<?php
// =============================================================
// notes/index.php - Listar notas del usuario
// Vulnerabilidad intencional: XSS (echo sin htmlspecialchars)
// =============================================================
require_once __DIR__ . '/../config.php';
requireLogin();

$user_id = $_SESSION['user_id'];

// Consulta de notas del usuario logueado
$query = "SELECT id, title, content, created_at FROM notes
          WHERE user_id = $user_id
          ORDER BY created_at DESC";
$result = pg_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mis Notas</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 40px auto; padding: 20px; }
        h1 { color: #334155; }
        .header { display: flex; justify-content: space-between; align-items: center; }
        .note { border: 1px solid #CBD5E1; padding: 15px; margin: 15px 0; border-radius: 4px; }
        .note h3 { margin: 0 0 8px 0; color: #334155; }
        .note-meta { color: #64748B; font-size: 12px; }
        .actions a { margin-right: 10px; color: #E0234E; text-decoration: none; }
        .btn { display: inline-block; padding: 8px 16px; background: #E0234E; color: white; text-decoration: none; border-radius: 4px; }
        .btn-logout { background: #64748B; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Mis Notas</h1>
        <div>
            Hola, <?php echo $_SESSION['user_name']; ?> |
            <a href="/notes/create.php" class="btn">+ Nueva Nota</a>
            <a href="/logout.php" class="btn btn-logout">Salir</a>
        </div>
    </div>

    <?php if (pg_num_rows($result) === 0): ?>
        <p>No tienes notas aún.</p>
    <?php else: ?>
        <?php while ($note = pg_fetch_assoc($result)): ?>
            <div class="note">
                <!-- VULNERABLE: echo sin htmlspecialchars permite XSS -->
                <h3><?php echo $note['title']; ?></h3>
                <p><?php echo $note['content']; ?></p>
                <div class="note-meta">Creada: <?php echo $note['created_at']; ?></div>
                <div class="actions">
                    <a href="/notes/edit.php?id=<?php echo $note['id']; ?>">Editar</a>
                    <form method="POST" action="/notes/delete.php" style="display:inline;">
                        <!-- SIN TOKEN CSRF - vulnerable -->
                        <input type="hidden" name="id" value="<?php echo $note['id']; ?>">
                        <button type="submit" onclick="return confirm('¿Eliminar?')"
                                style="background:none;border:none;color:#E0234E;cursor:pointer;">
                            Eliminar
                        </button>
                    </form>
                </div>
            </div>
        <?php endwhile; ?>
    <?php endif; ?>
</body>
</html>
