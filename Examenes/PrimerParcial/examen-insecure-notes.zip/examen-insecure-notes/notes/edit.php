<?php
require_once __DIR__ . '/../config.php';
requireLogin();

$id = $_GET['id'] ?? 0;
$user_id = $_SESSION['user_id'];

// VULNERABLE: concatenación directa
$query = "SELECT id, title, content FROM notes
          WHERE id = $id AND user_id = $user_id";
$result = pg_query($conn, $query);

if (!$result || pg_num_rows($result) === 0) {
    redirect('/notes/index.php');
}

$note = pg_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Nota</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 600px; margin: 40px auto; padding: 20px; }
        h1 { color: #334155; }
        label { display: block; margin-top: 12px; font-weight: bold; }
        input, textarea { width: 100%; padding: 8px; margin-top: 4px; box-sizing: border-box; font-family: inherit; }
        textarea { min-height: 150px; }
        button { margin-top: 16px; padding: 10px 20px; background: #E0234E; color: white; border: none; cursor: pointer; }
        a { color: #64748B; }
    </style>
</head>
<body>
    <h1>Editar Nota</h1>

    <!-- SIN TOKEN CSRF -->
    <form method="POST" action="/notes/update.php">
        <input type="hidden" name="id" value="<?php echo $note['id']; ?>">

        <label>Título:</label>
        <input type="text" name="title" value="<?php echo $note['title']; ?>" required>

        <label>Contenido:</label>
        <textarea name="content" required><?php echo $note['content']; ?></textarea>

        <button type="submit">Actualizar</button>
        <a href="/notes/index.php">Cancelar</a>
    </form>
</body>
</html>
