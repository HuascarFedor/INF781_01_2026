<?php
// =============================================================
// notes/delete.php - Eliminar nota
// Vulnerabilidades intencionales: sin token CSRF, SQLi
// =============================================================
require_once __DIR__ . '/../config.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/notes/index.php');
}

$id = $_POST['id'] ?? 0;
$user_id = $_SESSION['user_id'];

// VULNERABLE: concatenación + SIN validación de token CSRF
$query = "DELETE FROM notes WHERE id = $id AND user_id = $user_id";
pg_query($conn, $query);

redirect('/notes/index.php');
