<?php
require_once __DIR__ . '/../config.php';
requireLogin();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Nueva Nota</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 600px; margin: 40px auto; padding: 20px; }
        h1 { color: #334155; }
        label { display: block; margin-top: 12px; font-weight: bold; }
        input, textarea { width: 100%; padding: 8px; margin-top: 4px; box-sizing: border-box; font-family: inherit; }
        textarea { min-height: 150px; }
        button { margin-top: 16px; padding: 10px 20px; background: #E0234E; color: white; border: none; cursor: pointer; }
        a { color: #64748B; }
    </style>
</head>
<body>
    <h1>Nueva Nota</h1>

    <!-- SIN TOKEN CSRF - vulnerable -->
    <form method="POST" action="/notes/store.php">
        <label>Título:</label>
        <input type="text" name="title" required>

        <label>Contenido:</label>
        <textarea name="content" required></textarea>

        <button type="submit">Guardar</button>
        <a href="/notes/index.php">Cancelar</a>
    </form>
</body>
</html>
