#!/usr/bin/env bash
# =============================================================
# setup.sh - Setup rápido para laboratorio
# INF781 - Examen Parcial Práctico
# =============================================================

set -e

DB_NAME="examen_insecure_notes"
DB_USER="${DB_USER:-postgres}"

echo "==> Creando base de datos '$DB_NAME'..."
psql -U "$DB_USER" -c "DROP DATABASE IF EXISTS $DB_NAME;"
psql -U "$DB_USER" -c "CREATE DATABASE $DB_NAME;"

echo "==> Cargando schema..."
psql -U "$DB_USER" -d "$DB_NAME" -f sql/schema.sql

echo "==> Cargando datos de prueba..."
psql -U "$DB_USER" -d "$DB_NAME" -f sql/seed.sql

echo ""
echo "=============================================="
echo " Setup completo."
echo " Ejecutar ahora: php -S localhost:8000"
echo "=============================================="
