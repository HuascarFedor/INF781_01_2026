<?php
require_once __DIR__ . '/config.php';

if (isset($_SESSION['user_id'])) {
    redirect('/notes/index.php');
} else {
    redirect('/login.php');
}
