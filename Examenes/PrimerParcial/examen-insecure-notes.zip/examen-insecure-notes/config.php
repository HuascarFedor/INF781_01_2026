<?php
// =============================================================
// config.php - Configuración de la aplicación
// INF781 - Examen Parcial Práctico
// =============================================================
// ADVERTENCIA: Este archivo contiene vulnerabilidades intencionales
// con fines educativos. NO usar esta configuración en producción.
// =============================================================

// --- Visualización de errores (inseguro para producción) ---
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// --- Credenciales de base de datos (hardcodeadas) ---
$db_host = 'localhost';
$db_port = '5432';
$db_name = 'examen_insecure_notes';
$db_user = 'postgres';
$db_pass = 'postgres';

// --- Conexión a PostgreSQL ---
$conn = pg_connect("host=$db_host port=$db_port dbname=$db_name user=$db_user password=$db_pass");

if (!$conn) {
    die("Error de conexión a la base de datos: " . pg_last_error());
}

// --- Configuración de sesiones (inseguro) ---
ini_set('session.cookie_httponly', 0);   // JavaScript puede leer la cookie
ini_set('session.cookie_samesite', '');  // Sin restricción de origen
ini_set('session.cookie_secure', 0);     // Funciona sin HTTPS
ini_set('session.use_strict_mode', 0);   // Acepta IDs arbitrarios (permite fijación)

session_start();

// --- Helper de redirección ---
function redirect($url) {
    header("Location: $url");
    exit;
}

// --- Helper: verificar si hay sesión activa ---
function requireLogin() {
    if (!isset($_SESSION['user_id'])) {
        redirect('/login.php');
    }
}
