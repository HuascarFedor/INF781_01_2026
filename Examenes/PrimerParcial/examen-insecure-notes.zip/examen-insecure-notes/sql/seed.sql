-- =============================================================
-- Seeder de datos de prueba
-- Contraseñas almacenadas con MD5 (intencionalmente inseguro)
-- =============================================================

-- Usuarios de prueba
-- admin@uatf.edu / admin123   -> MD5: 0192023a7bbd73250516f069df18b500
-- estudiante@uatf.edu / 123456 -> MD5: e10adc3949ba59abbe56e057f20f883e
-- docente@uatf.edu / password  -> MD5: 5f4dcc3b5aa765d61d8327deb882cf99

INSERT INTO users (name, email, password) VALUES
    ('Administrador', 'admin@uatf.edu',     '0192023a7bbd73250516f069df18b500'),
    ('Ana Estudiante', 'estudiante@uatf.edu','e10adc3949ba59abbe56e057f20f883e'),
    ('Carlos Docente', 'docente@uatf.edu',  '5f4dcc3b5aa765d61d8327deb882cf99');

-- Notas de prueba (3 para el admin, 2 para la estudiante)
INSERT INTO notes (title, content, user_id) VALUES
    ('Nota administrativa', 'Recordar renovar las licencias del laboratorio antes del fin de mes.', 1),
    ('Credenciales de respaldo', 'Backup programado cada lunes a las 03:00 AM.', 1),
    ('Reunión de departamento', 'Agendada para el viernes a las 10:00 AM en sala de reuniones.', 1),
    ('Tarea de INF781', 'Terminar la práctica de SQL Injection antes del examen parcial.', 2),
    ('Compras', 'Comprar libro de criptografía aplicada y cuaderno nuevo.', 2);
